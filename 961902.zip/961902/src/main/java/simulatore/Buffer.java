package simulatore;

import simulatore.Measurement;

public interface Buffer
{
    void addMeasurement(Measurement m);
}
